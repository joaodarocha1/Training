﻿using System.Windows.Controls;

namespace StockMarket.Client.Control
{
    /// <summary>
    /// Interaction logic for PriceHistoryDialog.xaml
    /// </summary>
    public partial class PriceHistoryDialog : UserControl
    {
        public PriceHistoryDialog()
        {
            InitializeComponent();
        }
    }
}
