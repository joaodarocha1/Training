﻿using StockMarket.Service.Common;

namespace StockMarket.Service.Bloomberg.Publisher;

public class RandomPublishEventArgs
{
    public Quote Quote { get; set; }
}