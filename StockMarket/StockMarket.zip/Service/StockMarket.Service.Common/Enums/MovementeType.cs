﻿namespace StockMarket.Service.Common.Enums;

public enum MovementType
{
    None = 1,
    Up = 2,
    Down = 3,
}