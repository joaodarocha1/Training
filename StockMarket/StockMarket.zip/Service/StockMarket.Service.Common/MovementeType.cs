﻿namespace StockMarket.Service.Common;

public enum MovementType
{
    None = 1,
    Up = 2,
    Down = 3,
}