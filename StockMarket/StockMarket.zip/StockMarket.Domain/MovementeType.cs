﻿namespace StockMarket.Service;

public enum MovementType
{
    None = 1,
    Up = 2,
    Down = 3,
}