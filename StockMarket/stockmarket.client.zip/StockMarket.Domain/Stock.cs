﻿namespace StockMarket.Domain;

public class Stock
{
    public string Ticker { get; set; }
    public string Name { get; set; }
}