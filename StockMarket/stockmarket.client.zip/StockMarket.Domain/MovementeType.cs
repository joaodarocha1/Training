﻿namespace StockMarket.Domain;

public enum MovementType
{
    None = 1,
    Up = 2,
    Down = 3,
}